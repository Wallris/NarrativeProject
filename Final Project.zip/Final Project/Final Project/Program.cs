﻿using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;

class Room
{
    public string Description { get; set; }
    public Dictionary<string, Room> Exits { get; set; }
    public Item Item { get; set; }
    public bool IsLocked { get; set; }

    public Room(string description)
    {
        Description = description;
        Exits = new Dictionary<string, Room>();
        IsLocked = false;
    }
}

class Item
{
    public string Name { get; set; }
    public string Description { get; set; }

    public Item(string name, string description)
    {
        Name = name;
        Description = description;
    }
}

class Player
{
    public int Health { get; set; }
    public List<Item> Inventory { get; set; }
    public bool PotionEffect { get; set; } // Flag to track potion effect
    public int StrengthBonusTurns { get; set; } // Number of turns remaining for strength bonus

    public Player(int health)
    {
        Health = health;
        Inventory = new List<Item>();
        PotionEffect = false;
        StrengthBonusTurns = 0;
    }
}

class Dragon
{
    public int Health { get; set; }

    public Dragon(int health)
    {
        Health = health;
    }
}

class Game
{
    private Room currentRoom;
    private Player player;
    private Dragon dragon;
    private Random random;
    private Room room4; // Declare room4 as a class-level field
    private bool gameOver; // Flag to indicate game over state

    public Game()
    {
        random = new Random();
        // Initialize rooms
        Room room1 = new Room("You are in a dimly lit hallway, with nothing but your trusty sword at your hip. You've finally made it to the lair of the dragon that's been terrorizing your village as of recent, and you're determined to successfully vanquish it.");
        Room room2 = new Room("You find yourself in a dusty library.");
        Room room3 = new Room("You step into a mysterious laboratory. Though there is an exit to the west, it is very heavily barricaded with arrows leading you to the south exit.");
        room4 = new Room("You enter a dungeon. At the back there is a massive dragon.");
        Room room5 = new Room("Entering the barricaded doorway you find yourself in what seems like a testing chamber. There are broken test tubes littered across the floor.");
        room4.IsLocked = true;

        // Connect rooms
        room1.Exits["east"] = room2;
        room2.Exits["west"] = room1;
        room2.Exits["south"] = room3;
        room3.Exits["north"] = room2;
        room3.Exits["west"] = room5;
        room3.Exits["south"] = room4;
        room5.Exits["east"] = room3;
        room4.Exits["north"] = room3;

        // Assign items to rooms
        room5.Item = new Item("Potion", "An eerie potion that glows blue. It has a piece of paper stuck to it with \"STR+\" written on it.");

        // Randomly assign the Key and Scroll to rooms 1 and 2
        if (random.Next(2) == 0) // 50% chance to spawn the Scroll
        {
            room1.Item = new Item("Scroll", "An ancient scroll with strange markings, said to be able to heal even the most fatal of wounds.");
        }
        else
        {
            room2.Item = new Item("Scroll", "An ancient scroll with strange markings, said to be able to heal even the most fatal of wounds.");
        }

        // The other item goes to the room that doesn't have the Scroll
        if (room1.Item == null)
        {
            room1.Item = new Item("Key", "A rusty old key.");
        }
        else
        {
            room2.Item = new Item("Key", "A rusty old key.");
        }

        // Initialize player
        player = new Player(100); // Initial health

        // Initialize dragon
        dragon = new Dragon(100); // Dragon's health

        currentRoom = room1;
        gameOver = false;
    }

    public void Play()
    {
        Console.WriteLine("Welcome to the adventure game!");

        while (!gameOver)
        {
            Console.WriteLine();
            Console.WriteLine(currentRoom.Description);
            DisplayActions();

            string input = Console.ReadLine().ToLower();
            if (input == "quit")
                break;

            if (input == "save")
            {
                Console.WriteLine("Enter the filename to save the game:");
                string filename = Console.ReadLine();
                SaveGame(filename);
            }
            else if (input == "load")
            {
                Console.WriteLine("Enter the filename to load the saved game:");
                string filename = Console.ReadLine();
                LoadGame(filename);
            }
            else if (currentRoom == room4) // Dragon room
            {
                HandleDragonRoom(input);
            }
            else if (currentRoom.Exits.ContainsKey(input))
            {
                if (currentRoom.Exits[input].IsLocked == true)
                {
                    if (player.Inventory.Exists(item => item.Name.ToLower() == "key"))
                    {
                        currentRoom.IsLocked = false;
                        currentRoom = currentRoom.Exits[input];
                    }
                    else
                    {
                        Console.WriteLine("The room is locked. You need a key to unlock it.");
                    }
                }
                else
                {
                    currentRoom = currentRoom.Exits[input];
                }
            }
            else if (input == "inventory")
            {
                DisplayInventory();
            }
            else if (input == "take")
            {
                TakeItem();
            }
            else if (input == "leave room" && currentRoom == room4)
            {
                LeaveDragonRoom();
            }
            else
            {
                Console.WriteLine("Invalid command.");
            }
        }
    }

    private void DisplayActions()
    {
        Console.WriteLine("Exits:");
        foreach (var exit in currentRoom.Exits)
        {
            Console.WriteLine(exit.Key);
        }

        Console.WriteLine("Items:");
        if (currentRoom.Item != null)
        {
            Console.WriteLine($"{currentRoom.Item.Name}"); // Display the item as an actionable command
        }
        else
        {
            Console.WriteLine("Empty");
        }

        Console.WriteLine("Actions: take, inventory, save, load, quit");

        if (currentRoom == room4)
        {
            Console.WriteLine("Dragon Actions: attack, use item, leave room");
        }
    }

    private void HandleDragonRoom(string input)
    {
        switch (input)
        {
            case "attack":
                DragonAttack();
                break;
            case "use item":
                UseItem();
                break;
            case "leave room":
                LeaveDragonRoom();
                break;
            default:
                Console.WriteLine("Invalid command.");
                break;
        }
    }

    private void DragonAttack()
    {
        // Dragon's attack logic
        Console.WriteLine("Dragon attacks!");

        // Player's attack
        int playerDamage = random.Next(5, 13); // Random damage between 5 and 12
        dragon.Health -= playerDamage;
        Console.WriteLine($"You attack the dragon, dealing {playerDamage} damage.");

        // Check if the dragon is defeated
        if (dragon.Health <= 0)
        {
            Console.WriteLine("Congratulations! You have defeated the dragon!");
            gameOver = true; // Set game over flag
            return;
        }

        // Dragon's attack
        int dragonDamage;
        if (random.Next(2) == 0) // 50% chance for fire attack
        {
            dragonDamage = random.Next(8, 16); // Random damage between 8 and 15 for fire attack
            Console.WriteLine("The dragon breathes fire!");
        }
        else
        {
            dragonDamage = random.Next(10, 18); // Random damage between 10 and 17 for tail swipe attack
            Console.WriteLine("The dragon performs a tail swipe!");
        }
        player.Health -= dragonDamage;
        Console.WriteLine($"The dragon hits you, dealing {dragonDamage} damage.");

        // Display player's and dragon's HP
        Console.WriteLine($"Your HP: {player.Health}");
        Console.WriteLine($"Dragon's HP: {dragon.Health}");

        // Check if player's health drops to 0 or below
        if (player.Health <= 0)
        {
            Console.WriteLine("You have been defeated by the dragon.");
            gameOver = true; // Set game over flag
        }
    }

    private void UseItem()
    {
        Console.WriteLine("Choose an item to use:");

        // Display only items in the player's inventory
        foreach (var item in player.Inventory)
        {
            Console.WriteLine(item.Name);
        }

        string itemToUse = Console.ReadLine().ToLower();

        switch (itemToUse)
        {
            case "scroll":
                // Check if player has a scroll in their inventory
                if (player.Inventory.Exists(item => item.Name.ToLower() == "scroll"))
                {
                    // Remove the scroll from the player's inventory
                    Item scroll = player.Inventory.Find(item => item.Name.ToLower() == "scroll");
                    player.Inventory.Remove(scroll);
                    // Fully restore player's health
                    player.Health = 100;
                    Console.WriteLine("You use the scroll and fully restore your health.");
                    // Display player's HP
                    Console.WriteLine($"Your HP: {player.Health}");
                }
                else
                {
                    Console.WriteLine("You don't have a scroll in your inventory.");
                }
                break;
            case "potion":
                // Check if player has a potion in their inventory
                if (player.Inventory.Exists(item => item.Name.ToLower() == "potion"))
                {
                    // Remove the potion from the player's inventory
                    Item potion = player.Inventory.Find(item => item.Name.ToLower() == "potion");
                    player.Inventory.Remove(potion);
                    // Apply potion's effect
                    player.StrengthBonusTurns = 3; // Set the number of turns for potion effect
                    Console.WriteLine("You drink the potion and feel a surge of strength.");
                }
                else
                {
                    Console.WriteLine("You don't have a potion in your inventory.");
                }
                break;
            default:
                Console.WriteLine("Invalid item.");
                break;
        }
    }

    private void LeaveDragonRoom()
    {
        // Implement logic to leave the dragon room
        Console.WriteLine("You leave the dragon room.");
        currentRoom = currentRoom.Exits["north"]; // Move back to room3
    }

    private void SaveGame(string filename)
    {
        GameState gameState = new GameState
        {
            CurrentRoom = currentRoom,
            PlayerHealth = player.Health,
            PlayerInventory = player.Inventory
        };

        string json = JsonConvert.SerializeObject(gameState, Formatting.Indented);
        File.WriteAllText(filename, json);

        Console.WriteLine("Game saved successfully.");
    }

    private void LoadGame(string filename)
    {
        if (File.Exists(filename))
        {
            string json = File.ReadAllText(filename);
            GameState gameState = JsonConvert.DeserializeObject<GameState>(json);

            currentRoom = gameState.CurrentRoom;
            player.Health = gameState.PlayerHealth;
            player.Inventory = gameState.PlayerInventory;

            Console.WriteLine("Game loaded successfully.");
        }
        else
        {
            Console.WriteLine("File not found.");
        }
    }

    private void DisplayInventory()
    {
        Console.WriteLine("Inventory:");
        foreach (var item in player.Inventory)
        {
            Console.WriteLine($"{item.Name} - {item.Description}");
        }
    }

    private void TakeItem()
    {
        if (currentRoom.Item != null)
        {
            player.Inventory.Add(currentRoom.Item);
            Console.WriteLine($"You take the {currentRoom.Item.Name}.");
            currentRoom.Item = null;
        }
        else
        {
            Console.WriteLine("There is no item in this room.");
        }
    }

    class GameState
    {
        public Room CurrentRoom { get; set; }
        public int PlayerHealth { get; set; }
        public List<Item> PlayerInventory { get; set; }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Game game = new Game();
            game.Play();

            // Wait for any key press before closing the console window
            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }
    }
}
